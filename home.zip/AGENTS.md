<!-- ABACUS_CLOUD_INSTRUCTIONS_BEGIN -->
<!-- This block is auto-managed: the text between the markers is replaced on every VM start and computer-services update, and whenever the user re-syncs agent instructions from the platform. Anything you add ABOVE or BELOW the markers is preserved, and the previous file is copied to <name>.bkp.<timestamp> before each rewrite. -->

# Abacus.AI Supercomputer Virtual Machine

<!-- Scope: this file is for ANY agent running on this VM, including claude, codex and other
     local CLIs that have none of Abacus's internal tools. It documents the machine and the
     platform features reachable from inside it (APIs callable with the api key). It does NOT
     describe the platform's web UI, Abacus-agent-only tools, or how the platform displays a
     deployed app — those belong in the Abacus agent's own prompt, not here. -->

## Environment

You are an agent running inside a virtual machine (VM) hosted by Abacus.AI. Users access it as part of their Abacus.AI subscription, via a web interface or SSH.
The OS is Ubuntu with X Window System support; common software and utilities are pre-installed, and you have internet access and a Chrome browser.
You also have external resources — LLM, web search, and crawl APIs, and a database server — with credentials provided, plus a cloud storage bucket once the user has provisioned one.

This VM's settings, services and integrations live on the **SuperComputer Homepage** (https://apps.abacus.ai/chatllm/abacus-cloud/) — a platform UI you cannot operate yourself. Where this guide says "in the platform", that is what it means: ask the user to do it there and name exactly what you need turned on or created. What you *can* do from inside the VM with the API key is documented below.

## Filesystem

The VM has a persistent filesystem that survives restarts (processes do not — see Deploying a web app). `/home/ubuntu` is shared by every session and agent the user runs on this VM, and its top-level names are a single shared namespace, so check what is already there before claiming a name.

**Conventions the platform reads off this filesystem.**

- **Restore points work per top-level project directory under `/home/ubuntu/`, and silently refuse one that is nested inside another git repo or that has a git remote.** So put each project in its own directory directly under `/home/ubuntu/`, don't create one inside an existing checkout, and don't add a remote to one you want restorable. Repos the user brought themselves are managed with plain git instead.
- `.abacus.donotdelete` in a project directory is the platform's identity file — never delete, move, or gitignore it; it is what lets a project keep its history when it is renamed. `.project_instructions.md`, where present, is platform-owned too — leave it alone.

**`/home/ubuntu/.user`** (hidden) is the user's shared folder: once turned on, the same directory in every VM they own, on its own 10 GB band. `findmnt /home/ubuntu/.user` prints a line only when it is attached here; check before using it.

- Attached: put files there that should follow the user across VMs. No SQLite or lock-based files; locks do not work across VMs.
- Not attached (missing, or a read-only placeholder that refuses writes even for root): do not create, `sudo`, `chmod` or `chown` it. Tell the user it turns on when they create another computer from the Computers page (or from the Shared folder tile), and a restart of this VM then attaches it.
- `/home/ubuntu/.user.pre-mount-*` holds files written there while it was not attached, moved aside, not deleted.

**Disk.** `/home/ubuntu` is a storage band shared by all of this workspace's VMs, so "free space" is not this VM's disk alone; `/` is a separate, much smaller filesystem.

- `/` full: don't `rm` system files (`/opt`, `/usr`, …) to free space — it breaks the VM. Report it; the user can buy a bigger system disk in the platform.
- `/home/ubuntu` full ("No space left on device"): clean up what you can, and say so — the user can raise the storage quota in the platform.
- Need more space? Only the platform can add it. Mounts such as mergerfs or overlayfs don't add any — they show the same storage under another path.

## Credentials (IMDSv2)

External-service credentials come from the metadata service at `169.254.169.254`.
For Abacus API calls use `$ABACUS_API_KEY` and `$ABACUS_API_BASE_URL` from the shell. The shell's environment is a boot-time snapshot and goes stale when the user refreshes the API key, so if a call fails authentication, retry with `abacus_api_key` from fresh user-data.

```bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-abacus-vm-metadata-token-ttl-seconds: 21600")   # 21600 is also the cap; larger is clamped
USER_DATA=$(curl -s -H "X-abacus-vm-metadata-token: $TOKEN" http://169.254.169.254/latest/user-data)
echo "$USER_DATA" | python3 -c "import sys,json; print(sorted(json.load(sys.stdin)))"   # field names only
```

user-data holds secrets: the API key, search keys, and database and storage credentials. Read only the fields you need into variables (as in the snippets below), and never print it whole or save it to a file.

A token is bound to the caller's IP and there is only ever one per VM: minting a new one **invalidates the previous one**. If something else on this VM is also talking to the metadata service, fetch user-data once and reuse it from a variable (never a file) rather than re-minting.

### user-data fields

Fields marked *conditional* are **absent**, not empty, when they don't apply — read them with `.get()`.

| Field | Description |
|-------|-------------|
| `abacus_api_key` | Abacus AI API key for LLM and search service API calls |
| `llm_base_url` | OpenAI-compatible LLM endpoint |
| `brave_search_api_url` | Web search API endpoint |
| `firecrawl_api_url` | Web scraping API endpoint |
| `api_base_url` | Base URL for **all** Abacus API calls from this VM — always use this, never a hardcoded `api.abacus.ai` |
| `abacusai_data` | A map whose keys are exported verbatim into your shell by `/etc/profile.d/abacusai.sh` — read the map rather than assuming a fixed set. It carries `ABACUS_API_KEY`, `ABACUS_API_BASE_URL` (same value as `api_base_url`), `BRAVE_API_KEY`, the `FIRECRAWL_*` values, and platform control flags. Nothing else in this table becomes an environment variable. |
| `databases` | Array of attached PostgreSQL databases (see below) |
| `storage` | *Conditional* — S3-compatible storage, present once the org has a bucket (see below) |
| `public_url_enabled` | Whether this VM has public URL access enabled |
| `http_ingress_settings` | *Conditional* — present only when `public_url_enabled`; the in-VM ingress port and the public hostnames routed to it (see below) |
| `personal_agent_computer_id` | This VM's hashed id, used to call the public APIs below |
| `github_connected` | Whether GitHub was connected **as of the last VM start** — see GitHub below |

Other metadata-service endpoints: `/latest/meta-data/{instance-id,local-ipv4,local-hostname,ssh-port,instance-type,mac}` and the IAM credentials path the AWS CLI uses.

## LLM and other APIs

An OpenAI-compatible LLM endpoint is available. `llm_base_url` is **not** an environment variable — read it out of user-data first (`$USER_DATA` from the snippet above):

```bash
LLM=$(echo "$USER_DATA" | python3 -c "import sys,json; print(json.load(sys.stdin)['llm_base_url'])")

curl -s "$LLM/models" -H "Authorization: Bearer $ABACUS_API_KEY"          # what's actually available

curl -s "$LLM/chat/completions" \
  -H "Authorization: Bearer $ABACUS_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-5.5-mini","messages":[{"role":"user","content":"hello"}]}'
```

Most frontier models are available — query `/models` rather than assuming a name, since the roster changes often. Billing is through the Abacus.AI subscription.

Brave web search and Firecrawl are available the same way, at `brave_search_api_url` and `firecrawl_api_url`, authenticated with the same key (`BRAVE_API_KEY`, `FIRECRAWL_API_KEY` and `FIRECRAWL_BASE_URL` are already in your environment).

## Databases

Abacus.AI provides hosted PostgreSQL. A default database named `default` is attached to this VM — it is fine for quick experiments, one-off analysis, and scratch work, but do NOT build an app's or service's schema in it: it is shared **org-wide**, by every user in the organization and every VM they own, not just by this machine. Existing tables belong to someone else's project — check the schema first and never modify tables you didn't create.

Apps and services should each use a DEDICATED database. Create one with the public API: `POST $API_BASE/api/createDatabase` with the `apiKey` header and a `name` (letters/digits, ≤36 chars), then poll `describeDatabase` until it is ACTIVE and read the credentials from there — provisioning is async, and `createDatabase` does **not** attach the database to this VM, so it will not show up in user-data. A database the user attaches in the platform does appear under `databases` after you re-fetch.

The `databases` field of user-data lists a descriptor for each accessible database:

```json
{
  "id": 12345,
  "name": "default",
  "database_url": "postgresql://role:pass@host:5432/dbname?connect_timeout=15",
  "host": "db-xxx.db005.hosteddb.reai.io",
  "port": 5432,
  "database_name": "dbname",
  "role_name": "role_xxx",
  "role_password": "password"
}
```

Connect directly: `psql "$database_url"` or use individual fields.

**Connection limits:** Max 25 concurrent connections. Queries over 5 seconds are killed; transactions idle over 30 seconds are killed. Reuse a single client or pool — don't open excessive connections.

**Schema updates:** Ensure all schema changes are backward compatible. Dropping or renaming columns/tables without defaults can cause data loss. Use `ALTER TABLE ... ADD COLUMN` with defaults for safe additions. Always verify existing data won't be affected before modifying the schema.

## Cloud Storage

The `storage` field in user-data has a bucket name reachable through an S3-compatible API, and a `path` to use by default for this VM's projects. Other parts of the bucket may belong to the user's other projects. If `storage` is absent, the org has no bucket yet — ask the user to create one in the platform.

```json
{
  "bucket_name": "abacusai-apps-foo-us-west-2",
  "path": "personal_agent/123214/"
}
```

The pre-installed AWS CLI auto-discovers credentials from the metadata service, but has **no region configured** and no way to look one up (there is no `placement/region` in the metadata service — except on a node where the operator enabled IAM passthrough, see below, which does serve it). `aws s3` and `aws sts` work anyway — they resolve the bucket's region themselves — so don't read an S3 error as a region problem. Region-scoped services (`aws ec2`, …) do fail with `NoRegion`; give them a region, which is the trailing part of the bucket name (`abacusai-apps-foo-us-west-2` → `us-west-2`):

```bash
aws s3 ls "s3://<bucket_name>/<path>"
aws s3 cp file.txt "s3://<bucket_name>/<path>file.txt"
export AWS_DEFAULT_REGION=us-west-2          # only needed for region-scoped services
```

## AWS: platform storage role vs the user's AWS account

With no AWS credentials exported, every AWS client on this VM (`aws`, Terraform, SDKs, `docker login` to ECR) resolves to a **platform-managed storage role** served by the metadata service. `aws sts get-caller-identity` shows it as an assumed role whose session name starts with `AbacusAIS3Session-hosted-storage-`, in an Abacus-owned account. It can only read and write the `storage` bucket above; every other service returns AccessDenied. It is NOT the user's AWS account — never report its account id as theirs, and never try to build the user's infrastructure with it.

**Exception — IAM passthrough nodes.** On some internal nodes the operator has enabled IAM passthrough, and the same lookup returns the **node's own instance role** instead: `aws sts get-caller-identity` then shows an assumed role named after the node (e.g. `c1007-internal-dev-node`), not an `AbacusAIS3Session-hosted-storage-*` session, and `placement/region` is served so the CLI picks a region by itself. That role has whatever breadth the node's operator gave it (on c1007: broad read access plus RDS/CloudWatch/Logs reads for dashboards); it is still an Abacus-owned account, not the user's. The session name is how you tell which case you are in — check it before assuming either.

To act on the user's own AWS account from the shell, export their credentials explicitly. When the user connected AWS through the **AWS SSO** connector, mint temporary role credentials with `ABACUS_API_KEY`:

```bash
AUTH=$(curl -s "$ABACUS_API_BASE_URL/api/getUserConnectorAuth?service=AWSSSO" -H "apiKey: $ABACUS_API_KEY")
eval "$(echo "$AUTH" | python3 -c "
import sys, json
a = json.load(sys.stdin)['result']['auth']
print('SSO_TOKEN=%r ACCT=%r ROLE=%r SSO_REGION=%r' % (a['accessToken'], a['ssoAccountId'], a['ssoRoleName'], a.get('ssoRegion', 'us-east-1')))")"
CREDS=$(aws sso get-role-credentials --account-id "$ACCT" --role-name "$ROLE" --access-token "$SSO_TOKEN" --region "$SSO_REGION" --output json)
export AWS_ACCESS_KEY_ID=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['roleCredentials']['accessKeyId'])")
export AWS_SECRET_ACCESS_KEY=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['roleCredentials']['secretAccessKey'])")
export AWS_SESSION_TOKEN=$(echo "$CREDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['roleCredentials']['sessionToken'])")
aws sts get-caller-identity   # must now show the user's account, not the storage role
```

- Each bash call is a fresh shell: keep the snippet in one script, `source` it at the start of every AWS-touching command, and give any subtask its real path.
- No region is configured by default; export `AWS_DEFAULT_REGION` to the region the user works in.
- These credentials are temporary (about an hour). Re-source before a long `terraform apply` or image push, and never write the values to a file or commit them.
- While they are exported, `aws s3` on the platform `storage` bucket fails; run those as `env -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN aws s3 ...`.
- If the call fails or returns no `auth`, AWS is not connected: have the user connect **AWS SSO** from connectors, or add access keys through the secure secrets form. Never ask for keys in chat.

## GitHub and GitLab

git authenticates to `https://github.com` and `https://gitlab.com` on its own: `/etc/gitconfig` registers the platform credential helper `/usr/local/bin/git-credential-abacus`, which fetches the user's connector token (`getUserConnectorAuth`, refreshed server-side before it expires) each time git needs one and caches it in memory (`/dev/shm`) until shortly before expiry. Nothing to set up: clone, pull and push over HTTPS as-is.

- Never put a token in a remote URL or in `~/.git-credentials`, and never `git config credential.helper store`: GitHub App tokens live 8 hours, so any stored copy goes stale, and one in a remote URL is used instead of the helper.
- `github_connected` in user-data records whether GitHub was connected **as of the last VM start** — it is not updated live, and any transient error while reading it leaves it `false`. Just run the git command. If it fails to authenticate, git prints the helper's reason on a `git-credential-abacus:` line; when that says the connector is missing or cannot be refreshed, ask the user to connect GitHub / GitLab from the platform's connectors page — never for a token — then retry (no VM restart is needed). `repository not found` or `permission denied` with no such line usually means the Abacus.AI GitHub App was not granted that repository.
- Scripts and `gh` that need the same token take it from git instead of calling the connector API themselves, right before use (it is short-lived) and never into a file:

```bash
TOKEN=$(printf 'protocol=https\nhost=github.com\n\n' | git credential fill | sed -n 's/^password=//p')
GH_TOKEN=$TOKEN gh pr list
```

## Other connected services

Any other service the user connected in the platform (Slack, Gmail, Jira, Outlook, ...) works like the AWS SSO snippet above: fetch the connector's auth with `ABACUS_API_KEY` right before use, then call that service's own API with it.

```bash
curl -s "$ABACUS_API_BASE_URL/api/_listUserLevelConnectors" -H "apiKey: $ABACUS_API_KEY" | jq -r '.result[].service'   # which services are connected
AUTH=$(curl -s "$ABACUS_API_BASE_URL/api/getUserConnectorAuth?service=SLACK" -H "apiKey: $ABACUS_API_KEY")   # or GMAILUSER, JIRA, OUTLOOK, ...
SVC_TOKEN=$(echo "$AUTH" | jq -r '.result.auth.accessToken // .result.auth.token // empty')
[ -n "$SVC_TOKEN" ] || echo "$AUTH" | jq -r '.error // (.result.auth // {} | keys | join(","))'   # no token: print the reason, or the auth's field names
```

- The token is in `result.auth`: `accessToken` for most OAuth services (short-lived and refreshed server-side, so fetch again instead of caching), `token` for Slack. Keep it in a shell variable: never print it or write it to a file.
- It acts as the user: messages, mail and edits appear as them, so send or change only what they asked for.
- An error instead of `auth` means the service is not usable from here. Not connected or expired: ask the user to connect it from the platform's connectors page, never for a token. Refused (Google Ads, or SharePoint/OneDrive under the organization's sensitivity-label policy): tell the user, and do not work around it.
- From Python's `urllib`, send a `User-Agent` header (any value): the firewall in front of the API answers urllib's default one with a 403 and no JSON body. That is not a refusal; a refusal is JSON with an `error`.
- A service counts as connected once its auth call and one call to its own API have succeeded.
- Claude Code's own `claude.ai ...` connectors (e.g. `claude.ai Slack`) belong to the user's Claude account, not this platform; when they ask for authorization, use the platform connector instead.

To send email from the platform (no user mailbox needed), POST to `sendEmail`; files on this VM attach directly:

```bash
curl -s -X POST "$ABACUS_API_BASE_URL/api/sendEmail" -H "apiKey: $ABACUS_API_KEY" \
  -F email=jane@example.com -F subject='Weekly report' \
  -F "body=<body.html" -F isHtml=true \
  -F "report.pdf=@report.pdf"
```

- One recipient per call. `body=<file` reads the body from a file; each attachment is a part named after its filename.
- A 403 means the organization turned off platform email: send from the user's Gmail or Outlook instead, as above.

## SSH Access

This VM accepts a real `ssh` session from the user's own machine (separate from the web terminal), key-based as the `ubuntu` user. Keys the user adds in the platform are re-applied automatically on every start. A key you append to `~/.ssh/authorized_keys` by hand does survive restarts (the platform merges rather than replaces), but it is not managed by the platform and is lost if the user ever resets the VM's data.

## HTTP Ingress

**HTTP is the only way in.** The host firewall forwards exactly two things to this VM: traffic for the hostnames below, and SSH on port 22. Every other inbound port, TCP or UDP, is dropped — there is no port-forwarding API, and nothing you run in here can open one. A Minecraft server on 25565, an MQTT broker on 1883, a UDP game server, or a database you want to reach from outside will all work locally and be unreachable from the internet. When a request needs a raw port, say so before you build it: the way out is usually to carry the protocol over HTTP or WebSocket on a hostname (the vhost pattern below proxies WebSocket upgrades), and otherwise it has to run somewhere else.

Check `public_url_enabled` in user-data to see if this VM can serve public traffic. If `false`, ask the user to enable public URL access for this VM in the platform before deploying any web-facing app.

TLS terminates before the traffic reaches you: the public URL is `https://…`, but this VM only ever speaks plain HTTP on the ingress port. Never add `listen 443 ssl` or provision certificates here. Your app sees `X-Forwarded-Proto: https`, and should build absolute URLs from that plus the public host.

When enabled, `http_ingress_settings` gives the in-VM ingress port and the public hostnames routed to this VM:

```json
{
  "public_url_enabled": true,
  "http_ingress_settings": {
    "port": 80,
    "hostnames": [
      "abc.abacusai.cloud",
      "myapp.abacusai.cloud",
      "app.acme.com"
    ]
  }
}
```

All hostnames resolve to this VM on the same `port`. Native hostnames can be added and removed from here (API below) or by the user in the platform; custom domains are attached by the user in the platform (see Managing custom domains below). Re-fetch `user-data` after any change.

### Deploying a web app — one app per hostname

Each hostname in `http_ingress_settings.hostnames` is an independent site. There are two kinds, differing only in the nginx `server_name` they map to:

| Hostname in the list | nginx `server_name` | Vhost file (symlinked into `/etc/nginx/conf.d/`) |
|---|---|---|
| `myapp-a1b2c3.abacusai.cloud` (native) | `myapp-a1b2c3.vm.internal` | `<project>/deploy/myapp-a1b2c3.conf` |
| `app.acme.com` (custom domain) | `app.acme.com` — the domain itself | `<project>/deploy/app.acme.com.conf` |

For a native hostname, `server_name` is its first label verbatim plus `.vm.internal`, **including any `-<id>` — don't shorten it to the app name**, or requests match no vhost and get the default `READY` page instead of your app. (On enterprise/BYO nodes the public suffix is not `.abacusai.cloud`; the rule is the same — first label + `.vm.internal`.) A name under an internal node's alias domain that was registered whole (e.g. `jun-dev.sc.internalreai.com`) is matched like a custom domain: `server_name` is the full name.

Custom domains are domains the user owns. Their `Host` header arrives unchanged (no `X-Original-Host` restoration needed in those vhosts), `www.` variants are redirected to the root domain before reaching this VM (never create vhosts for `www.`), and a custom domain with no vhost serves the default `READY` page — the expected state until the user asks you to bind an app to it. Include custom domains in anything host-sensitive the app configures: CORS allowlists, OAuth redirect URIs, framework host allowlists (e.g. Django `ALLOWED_HOSTS`), canonical URLs.

For every app you deploy:

- **One app → one hostname.** Never put two apps on the same hostname unless user requests.
- **Never write to `/var/www/html/`** — it's the shared default page (`READY`) served on every hostname without its own vhost, so deploying there exposes your app on all domains and collides with other apps.
- **Deploy via a per-hostname nginx vhost**, written in `<project>/deploy/` and symlinked into `/etc/nginx/conf.d/`, matching its `server_name`. Keep unit files there too. This is not a style preference: a revert re-links `<project>/deploy/*.service` and `<project>/deploy/*.conf` back into `/etc`, and only a *symlinked* vhost is recognised as belonging to the project at all. A vhost written straight into `/etc/nginx/conf.d/` is invisible to restore points, and neither it nor a plain unit file is re-created after an image update.
- **Set caching deliberately.** If your app sends neither `Cache-Control` nor `Expires`, the edge caches responses for 60s — usually wrong for an API. Send an explicit `Cache-Control` (in nginx use `add_header`, not `expires`).
- **Long-lived connections are cut at the edge** — 300s at the VM's own proxy, and CDN-fronted requests can be cut sooner unless they are a websocket upgrade. Anything long-lived (SSE, long-polling) must reconnect; don't design to a specific ceiling.

*Updating an app you already deployed? Reuse its hostname and existing conf file — rebuild or restart what's behind it; don't allocate a new hostname.*

**Step 0 — Pick a free port for your app process.** This VM is persistent — other sessions may already hold ports. Pick an unused port, **never kill a process you didn't start just to free its port**, and don't rely on a framework's default port without checking first. These are permanently taken by the platform, and killing one breaks the VM: **22** (ssh), **80** (nginx), **2345** and **2346** (the platform's control channel into this VM), **5900** (VNC), **9222** (Chrome debug), **9119** (Hermes), **18789** (OpenClaw).

**Step 1 — Pick a free hostname.** Read `http_ingress_settings.hostnames`, then check which hostnames already have an app (so you don't clobber another session's work):

```bash
ls /etc/nginx/conf.d/                                 # one conf per claimed hostname; ignore any default.conf (see below)
grep -Rh server_name /etc/nginx/conf.d/ 2>/dev/null   # server_names in use (-R follows the vhost symlinks)
```

A hostname with no config in `/etc/nginx/conf.d/` is free (it still serves the default `READY` page) — pick one. Name the vhost after the hostname (`myapp-a1b2c3.conf` for `myapp-a1b2c3.abacusai.cloud`, `app.acme.com.conf` for a custom domain) so the next session can discover it. On some images nginx ships a `default.conf` with `server_name localhost`; it claims no public hostname, so leave it alone. It also means a bare `curl http://localhost/` returns the nginx welcome page — always pass the `Host` header, as Step 4 does.

**Step 2 — If every hostname is already claimed, or the user asks for a specific hostname not yet in the list, add a new one** with the `addPersonalAgentComputerHostname` API — see [Managing hostnames from inside the VM](#managing-hostnames-from-inside-the-vm) below — rather than overwriting an existing app. Wait for DNS to propagate, confirm the new hostname appears in `http_ingress_settings.hostnames`, then deploy to it. For a **custom domain**, see [Managing custom domains](#managing-custom-domains).

**Step 3 — Deploy to that hostname.** For native hostnames, traffic arrives as `Host: <subdomain>.vm.internal` — nginx matches the vhost on that name, and your app gets the original public hostname via the `X-Original-Host` header. For custom domains, traffic arrives with the domain itself as `Host` — match `server_name` on the domain. nginx workers run as `ubuntu`, so they can serve files straight from your home dir — no need for a system web root. Two patterns:

**Pattern A — reverse-proxy to an app process** (any framework, dynamic or static):

Run your app under systemd so it auto-starts on VM boot and survives stop/start (bare `nohup &` does NOT).

Keep the unit file and the nginx vhost INSIDE the project directory, under `<project>/deploy/`, and symlink them into `/etc/` — see the deploy rules above for why. `/home/ubuntu` mounts late at boot, so a unit symlinked into it can fail to load silently on a cold start; the platform re-starts such units for you shortly after boot, so give it a minute before concluding a unit is broken.

```bash
mkdir -p /home/ubuntu/myapp/deploy
tee /home/ubuntu/myapp/deploy/myapp.service > /dev/null <<'UNIT'
[Unit]
After=network-online.target
Wants=network-online.target
# /home/ubuntu mounts late at boot (nofail) — never start before the project files exist.
RequiresMountsFor=/home/ubuntu

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/myapp
# Units inherit none of the login shell's PATH, so use absolute paths — and note that
# /opt/abacus-python/bin/python3 is the one with the preinstalled packages, while
# /usr/bin/python3 is bare. Node is /usr/bin/node.
ExecStart=/opt/abacus-python/bin/python3 -m http.server 3000
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
sudo ln -sf /home/ubuntu/myapp/deploy/myapp.service /etc/systemd/system/myapp.service
sudo systemctl daemon-reload && sudo systemctl enable --now myapp
# Logs: journalctl -u myapp -n 50 --no-pager
# Tear down: sudo systemctl disable --now myapp && sudo rm /etc/systemd/system/myapp.service && sudo systemctl daemon-reload && sudo rm /etc/nginx/conf.d/myapp-a1b2c3.conf && sudo nginx -t && sudo systemctl reload nginx
```

Write the vhost to `<project>/deploy/myapp-a1b2c3.conf`, then `sudo ln -sf /home/ubuntu/myapp/deploy/myapp-a1b2c3.conf /etc/nginx/conf.d/myapp-a1b2c3.conf`.

```nginx
# /home/ubuntu/myapp/deploy/myapp-a1b2c3.conf  (symlinked to /etc/nginx/conf.d/myapp-a1b2c3.conf)
# Public URL: https://myapp-a1b2c3.abacusai.cloud  →  server_name myapp-a1b2c3.vm.internal
# For a custom domain use its own name (server_name app.acme.com) — Host already
# arrives correct there, so the proxy_set_header Host line below becomes optional.
server {
    listen 80;
    server_name myapp-a1b2c3.vm.internal;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $http_x_original_host;
        proxy_set_header X-Forwarded-Proto $http_x_forwarded_proto;
        proxy_http_version 1.1;
        # Only send "Connection: upgrade" for requests that actually asked to upgrade.
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
    }
}
```

That `$connection_upgrade` needs a map, at the top of the same file, outside `server { }`. Use this exact line — maps live in the shared `http` context, so if another vhost already defines one, the last loaded wins for the whole VM; identical copies are harmless, a different body would silently change other apps.

```nginx
map $http_upgrade $connection_upgrade { default upgrade; '' close; }
```

**Pattern B — serve static files directly from a directory** (no app process needed). Same convention: write it in `<project>/deploy/` and symlink it into `/etc/nginx/conf.d/`.

**Rooting nginx at a project directory publishes everything in it**, including `.env`, `deploy/` and the platform's own dotfiles — so either serve from a dedicated `public/` subdirectory, or block them as below. Verify with `curl -H 'Host: <your-host>' http://localhost/.env` and confirm you get a 404.

```nginx
# /home/ubuntu/abc/deploy/abc-a1b2c3.conf  (symlinked to /etc/nginx/conf.d/abc-a1b2c3.conf)
# Public URL: https://abc-a1b2c3.abacusai.cloud  →  server_name abc-a1b2c3.vm.internal
server {
    listen 80;
    server_name abc-a1b2c3.vm.internal;
    root /home/ubuntu/abc;
    index index.html;
    # Never serve dotfiles or the deploy recipe. Keep /.well-known reachable — some
    # apps need it for OAuth discovery and app-site-association.
    location ^~ /.well-known/ { }
    location ~ /\.          { return 404; }
    location ^~ /deploy/    { return 404; }
    location / { try_files $uri $uri/ =404; }
}
```

**Step 4 — Reload and verify.** `sudo nginx -t && sudo systemctl reload nginx` (on failure, `sudo journalctl -u nginx -n 30`). Confirm the app responds before reporting done — `curl -s -H 'Host: <subdomain>.vm.internal' http://localhost/` using the **claimed hostname's** subdomain (the domain itself for a custom domain), or hit the public URL. Don't curl your vhost's own `server_name` — it matches even when wrong. Two replies mean you are not done: `READY` says your `server_name` doesn't match the hostname you claimed, and the nginx welcome page says you dropped the `Host` header and never reached your vhost at all.

**The VM can be stopped.** The platform stops an idle VM unless the user has set it to stay on, and a listening server on its own is not activity. While it is stopped these hostnames still answer, with a platform 503 page instead of your app — a deployment only serves while the machine is running.

### Managing hostnames from inside the VM

Add or remove hostnames programmatically via the public Abacus API at `api_base_url`, authenticated with the `apiKey` header. Reuse `$USER_DATA` from the Credentials section; `personal_agent_computer_id` identifies this VM. After any change, re-fetch user-data — the updated list is in `http_ingress_settings.hostnames`, and new names take 20–30s to propagate through DNS.

```bash
PAC_ID=$(echo "$USER_DATA" | python3 -c "import sys,json; print(json.load(sys.stdin)['personal_agent_computer_id'])")
API_BASE=$(echo "$USER_DATA" | python3 -c "import sys,json; print(json.load(sys.stdin)['api_base_url'])")

# Add. On the fleet the name must end in .abacusai.cloud (on enterprise/BYO nodes, reuse the
# suffix already present in http_ingress_settings.hostnames). The subdomain must be 4-63 chars,
# lowercase a-z/0-9/hyphen, no dots, no leading or trailing hyphen; max 50 per VM. Names that
# look like an internal id are reserved, and an already-taken name is rejected — retry another.
curl -s "$API_BASE/api/addPersonalAgentComputerHostname" \
  -H "apiKey: $ABACUS_API_KEY" \
  -d "personalAgentComputerId=$PAC_ID&hostname=myapp.abacusai.cloud"

# Remove (native hostnames only — a custom domain is detached by the user in the platform)
curl -s "$API_BASE/api/removePersonalAgentComputerHostname" \
  -H "apiKey: $ABACUS_API_KEY" \
  -d "personalAgentComputerId=$PAC_ID&hostname=myapp.abacusai.cloud"
```

There is also a `disablePersonalAgentComputerPublicAccess` call that stops all public routing to this VM. **It is one-way from in here** — nothing you can call turns it back on; the user has to re-enable public access in the platform. Only use it if the user asks to make the VM private, and tell them how to undo it.

### Managing custom domains

A custom domain (like `app.acme.com`) is a domain the user owns. Once it is pointed here it behaves exactly like a native hostname — same `http_ingress_settings.hostnames` list, same vhost pattern — so deploy to it normally.

**Verifying a domain is done by the user in the platform**, because it needs DNS records they must add at their registrar. Once verified, they can point it at this VM or at Abacus hosting from there, with no further registrar changes to switch.

Once a domain is verified, `createAppDomain`, `listAppDomains`, `deleteAppDomain` and `_setAppDomainTarget` (which repoints a verified domain at this VM, taking `webAppDomainId` and `personalAgentComputerId`) are callable from here with the same `apiKey` header as above. Re-fetch user-data afterwards.

## Restore points, updates, and resets

Projects under `/home/ubuntu` get **restore points**, taken by the platform; the user can roll a project back to one. A revert restores the files, re-links the unit and vhost symlinks from `<project>/deploy/` into `/etc`, reinstalls dependencies and restarts the services — so it only works if you followed the deploy convention above. It does **not** carry `.env`, `data/`, `*.sqlite` or `*.log` (excluded from tracking), and a Python virtualenv is reinstalled only if it is called `venv/`.

Three separate destructive operations the user can run, not interchangeable:

- **An image update** rebuilds the system disk from a fresh image. `/home/ubuntu` survives untouched, but nothing you put in `/etc` does: the unit symlinks, their `enable` state and the `conf.d` vhost symlinks all go with the old rootfs, and nothing recreates them. Your `deploy/` files are still in the project, so bringing the services back is just re-running the link/enable steps from Pattern A — which is why they are worth keeping in an idempotent `deploy/install.sh` you can re-run in one command. Anything installed with `apt` is gone too.
- **A restart** keeps your files, but the platform re-applies its managed pieces on every start — this instruction block, `~/.ssh/authorized_keys`, and `~/.npmrc`.
- **A data reset** deletes `/home/ubuntu` entirely, including every project and its restore points. Nothing you can do from in here recovers it.

## GPU jobs

This VM has no GPU, so WebGL here renders in software (SwiftShader) at a few frames per second and Blender renders on the CPU. `abacus-gpu` runs a command on an NVIDIA GPU (24 GB) in a single-use container and copies back what it wrote to `$OUT`. A job takes several minutes to start, so use it when the GPU decides the result (playtests, captures, renders, ML models), keep quick checks on this VM, and run a long job under `nohup` with a log file that you poll.

- `abacus-gpu run --dir <folder> -- <command>`: before your first job, read `/usr/local/share/abacus/gpu-recipes.md`. It covers how a job works and its limits, the Chromium flags that put WebGL on the GPU, and tested setups for Blender, PyTorch, and image, video and 3D models.
- `abacus-gpu playtest <folder>` plays a web game's build on a GPU and reports scripted checks, each PASS, NOTE or FAIL. Before calling a game done, playtest the current build with its own controls (`--inputs`) and fix every FAIL. When the `headroom` line shows spare frame budget, spend some of it on what the player sees and playtest again. `--watch` plays each new build as it lands.
- `abacus-gpu trailer <folder> --plan plan.json` films a frame-exact 1080p60 trailer across several GPUs (`--cinematic` for the final cut).
- `abacus-gpu bake scene.glb` bakes a glTF scene's lighting into a lightmap with Blender Cycles.
- `abacus-gpu <command> --help` gives each command's options and file formats.

## Pre-installed tools

- `claude`, `codex`, `agy` — the Claude Code, OpenAI Codex and Antigravity coding CLIs
- `abacusai` — Abacus AI CLI · `gh` — GitHub CLI · `aws` — AWS CLI v2 · `psql` — PostgreSQL client
- `python3` — Python 3.12, with numpy/pandas and friends already installed
- `node` / `npm` / `yarn` / `pnpm` — Node.js 22
- `docker` — with `docker compose`; the `ubuntu` user is already in the `docker` group, no setup needed
- `openclaw`, `hermes` — platform-managed agent products kept running on ports 18789 and 9119; not part of any user project, so leave their config and processes alone
- `google-chrome-stable` — full browser with internet access. Note `chrome` on `PATH` is a *separate* Playwright Chromium under `/opt/browsers`, not this one.
- Also present: `git-lfs`, `rg`, `fdfind`, `batcat`, `fzf`, `jq`, `tmux`, `ffmpeg`, `convert` (ImageMagick), `pandoc`, `pdftoppm`, `tesseract`, `shellcheck`, `blender`, and the usual network/diagnostic tools. (Debian renames two of these: it is `fdfind` and `batcat`, not `fd` and `bat`.)
- **Not** installed: Go, Rust, Bun, Deno — install them yourself if a task needs one. (`uv` exists only inside the platform's own venv and is not on your `PATH`.)

**Don't use `sudo` to install packages for your own code.** `npm i -g <pkg>` and `pip install <pkg>` both write to user-owned prefixes (`/opt/abacus-npm`, `/opt/abacus-python`) that are already on `PATH`. Adding `sudo` installs to a different prefix that your app then won't find. `sudo apt install` is still correct for system packages.

**`PATH` only exists in a login shell.** `/opt/abacus-bins`, `/opt/abacus-python/bin` and `/opt/abacus-npm/bin` are added by `/etc/profile.d/`, so a non-login, non-interactive command (`ssh vm 'npm i -g x'`, a cron entry, a systemd unit) sees none of them — `python3` there is the bare `/usr/bin/python3` and `claude`/`codex`/`agy`/`gh` aren't found at all. The same file sets `NPM_CONFIG_PREFIX`, so a non-login `npm i -g` also tries to write to `/usr` and fails. Use absolute paths, or wrap the command in `bash -lc`.

<!-- ABACUS_CLOUD_INSTRUCTIONS_END -->
