# -*- coding: utf-8 -*-
"""
Generator brožúry "Digitálna gramotnosť – PRÁCA".
Vytvára plne editovateľný PPTX (A4 na výšku) pomocou python-pptx.
Každý prvok je samostatný objekt (text box / shape) – nič nie je rasterizované.
"""

from pptx import Presentation
from pptx.util import Cm, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn


def set_line_dash(shp, val="dash"):
    """Nastaví prerušovaný okraj cez XML (enum nie je dostupný v tejto verzii)."""
    ln = shp.line._get_or_add_ln()
    for old in ln.findall(qn("a:prstDash")):
        ln.remove(old)
    dash = ln.makeelement(qn("a:prstDash"), {"val": val})
    ln.append(dash)

# ---------- KONŠTANTY ----------
FONT = "Calibri"

DARK_BLUE = RGBColor(0x1F, 0x3A, 0x5F)   # nadpisy + čísla úloh
GREY = RGBColor(0x5A, 0x5A, 0x5A)        # sekcie / čiary
LIGHT_BLUE = RGBColor(0xDB, 0xEA, 0xF7)  # jemné výplne sekcií
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
BLACK = RGBColor(0x22, 0x22, 0x22)
PH_FILL = RGBColor(0xF2, 0xF2, 0xF2)     # veľmi svetlá sivá výplň placeholderov
PH_LINE = RGBColor(0xA6, 0xA6, 0xA6)     # sivá čiara placeholderov
LIGHT_GREY_LINE = RGBColor(0xC9, 0xC9, 0xC9)

PAGE_W = Cm(21.0)
PAGE_H = Cm(29.7)
MARGIN = Cm(1.6)
CONTENT_W = PAGE_W - 2 * MARGIN

prs = Presentation()
prs.slide_width = PAGE_W
prs.slide_height = PAGE_H
BLANK = prs.slide_layouts[6]


# ---------- POMOCNÉ FUNKCIE ----------
def add_slide():
    return prs.slides.add_slide(BLANK)


def _set_run(run, size, bold, color, font=FONT, italic=False):
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    # zaisti font aj pre East Asian / complex script (bezpečné pre diakritiku)
    rPr = run._r.get_or_add_rPr()
    for tag in ("a:latin", "a:cs", "a:ea"):
        el = rPr.find(qn(tag))
        if el is None:
            el = rPr.makeelement(qn(tag), {})
            rPr.append(el)
        el.set("typeface", font)


def add_text(slide, x, y, w, h, text, size=12, bold=False, color=BLACK,
             align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, font=FONT,
             italic=False, line_spacing=None, wrap=True):
    """Pridá editovateľný text box. text môže byť string alebo list riadkov."""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = Cm(0.1)
    tf.margin_right = Cm(0.1)
    tf.margin_top = Cm(0.05)
    tf.margin_bottom = Cm(0.05)
    lines = text if isinstance(text, list) else [text]
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if line_spacing:
            p.line_spacing = line_spacing
        run = p.add_run()
        run.text = line
        _set_run(run, size, bold, color, font, italic)
    return tb


def add_rect(slide, x, y, w, h, fill=None, line=None, line_w=1.0,
             dash=None, round_=False):
    shp_type = MSO_SHAPE.ROUNDED_RECTANGLE if round_ else MSO_SHAPE.RECTANGLE
    shp = slide.shapes.add_shape(shp_type, x, y, w, h)
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
        if dash is not None:
            set_line_dash(shp, dash)
    shp.shadow.inherit = False
    return shp


def add_shape(slide, shape_type, x, y, w, h, fill=None, line=None, line_w=1.0):
    shp = slide.shapes.add_shape(shape_type, x, y, w, h)
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def set_shape_text(shp, text, size=12, bold=False, color=BLACK,
                   align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE,
                   italic=False, margin_left=Cm(0.15)):
    tf = shp.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = margin_left
    tf.margin_right = Cm(0.15)
    tf.margin_top = Cm(0.1)
    tf.margin_bottom = Cm(0.1)
    lines = text if isinstance(text, list) else [text]
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        run = p.add_run()
        run.text = line
        _set_run(run, size, bold, color, italic=italic)
    return shp


def placeholder_frame(slide, x, y, w, h, label, size=11):
    """Svetlosivý obdĺžnik s prerušovaným okrajom + centrovaný popis (pre screenshoty)."""
    shp = add_rect(slide, x, y, w, h, fill=PH_FILL, line=PH_LINE, line_w=1.25,
                   dash="dash")
    set_shape_text(shp, label, size=size, bold=False, color=GREY,
                   align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    return shp


def add_line(slide, x, y, w, color=GREY, weight=1.0):
    ln = slide.shapes.add_connector(2, x, y, x + w, y)
    ln.line.color.rgb = color
    ln.line.width = Pt(weight)
    ln.shadow.inherit = False
    return ln


# ---------- ZDIEĽANÁ ŠABLÓNA ----------
def add_footer(slide):
    y = PAGE_H - Cm(1.5)
    add_line(slide, MARGIN, y, CONTENT_W, color=LIGHT_GREY_LINE, weight=0.75)
    add_text(slide, MARGIN, y + Cm(0.1), CONTENT_W, Cm(0.9),
             "[PRIESTOR NA LOGÁ A POVINNÉ INFORMÁCIE O PROJEKTE]",
             size=9, color=GREY, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE,
             italic=True)


def add_header(slide, title, subtitle):
    """Horný pruh hlavičky pracovného listu."""
    band = add_rect(slide, 0, 0, PAGE_W, Cm(2.6), fill=DARK_BLUE)
    add_text(slide, MARGIN, Cm(0.45), CONTENT_W, Cm(1.0), title,
             size=20, bold=True, color=WHITE, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.MIDDLE)
    add_text(slide, MARGIN, Cm(1.5), CONTENT_W, Cm(0.9), subtitle,
             size=14, bold=False, color=LIGHT_BLUE, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.MIDDLE)
    # tenký akcentový prúžok pod hlavičkou
    add_rect(slide, 0, Cm(2.6), PAGE_W, Cm(0.12), fill=LIGHT_BLUE)


def add_name_date(slide, y):
    add_text(slide, MARGIN, y, CONTENT_W / 2, Cm(0.9),
             "Meno: __________________________", size=13, color=BLACK,
             anchor=MSO_ANCHOR.MIDDLE)
    add_text(slide, MARGIN + CONTENT_W / 2, y, CONTENT_W / 2, Cm(0.9),
             "Dátum: _________________________", size=13, color=BLACK,
             anchor=MSO_ANCHOR.MIDDLE)


def add_task_label(slide, y, num, w=CONTENT_W):
    """Editovateľný nadpis úlohy 'Úloha N' s modrým číslom v krúžku."""
    d = Cm(0.9)
    badge = add_shape(slide, MSO_SHAPE.OVAL, MARGIN, y, d, d, fill=DARK_BLUE)
    set_shape_text(badge, str(num), size=14, bold=True, color=WHITE)
    add_text(slide, MARGIN + d + Cm(0.25), y, w - d - Cm(0.25), d,
             "Úloha %d" % num, size=16, bold=True, color=DARK_BLUE,
             anchor=MSO_ANCHOR.MIDDLE)
    return y + d + Cm(0.15)


def add_zadanie(slide, y, text, w=CONTENT_W, h=Cm(1.4)):
    """Blok so zadaním úlohy na jemnom svetlomodrom pozadí."""
    box = add_rect(slide, MARGIN, y, w, h, fill=LIGHT_BLUE)
    # výrazný ľavý gap: text má veľký ľavý okraj, aby sa modrý prúžok
    # nedotýkal prvých písmen (breathing space)
    set_shape_text(box, text, size=13.5, bold=False, color=DARK_BLUE,
                   align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.MIDDLE,
                   margin_left=Cm(0.55))
    # ľavý akcentový prúžok
    add_rect(slide, MARGIN, y, Cm(0.18), h, fill=DARK_BLUE)
    return box


def add_answer_circle(slide, cx, cy, d=Cm(1.3)):
    """Prázdny krúžok (obrys) pre zakrúžkovanie odpovede."""
    c = add_shape(slide, MSO_SHAPE.OVAL, cx - d / 2, cy - d / 2, d, d,
                  fill=None, line=GREY, line_w=1.75)
    return c


# ======================================================================
# STRANA 1 – TITULNÁ
# ======================================================================
def page_title():
    s = add_slide()
    # jemný horný a dolný akcent
    add_rect(s, 0, 0, PAGE_W, Cm(0.5), fill=DARK_BLUE)
    add_rect(s, 0, PAGE_H - Cm(0.5), PAGE_W, Cm(0.5), fill=DARK_BLUE)

    add_rect(s, MARGIN, Cm(9.5), CONTENT_W, Cm(0.12), fill=LIGHT_BLUE)
    add_text(s, MARGIN, Cm(10.2), CONTENT_W, Cm(3.2),
             "Digitálna gramotnosť – PRÁCA",
             size=30, bold=True, color=DARK_BLUE, align=PP_ALIGN.CENTER,
             anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, MARGIN, Cm(13.6), CONTENT_W, Cm(1.4),
             "Pracovné listy pre úroveň SKKR 1",
             size=18, bold=False, color=GREY, align=PP_ALIGN.CENTER,
             anchor=MSO_ANCHOR.MIDDLE)
    add_rect(s, MARGIN + CONTENT_W / 2 - Cm(3), Cm(15.4), Cm(6), Cm(0.08),
             fill=LIGHT_GREY_LINE)
    add_footer(s)
    return s


# ======================================================================
# STRANA 2 – PRACOVNÝ LIST 1 – 1.1 Hľadanie práce
# ======================================================================
def page_ws1():
    s = add_slide()
    add_header(s, "Pracovný list 1", "1.1 Hľadanie práce")
    add_name_date(s, Cm(3.1))

    # --- Úloha 1 ---
    y = Cm(4.4)
    y = add_task_label(s, y, 1)
    add_zadanie(s, y,
                "Pozrite si tri obrázky webových stránok. Zakrúžkujte stránku, "
                "na ktorej môžete hľadať pracovné ponuky.",
                h=Cm(1.5))
    y += Cm(1.7)

    labels = [
        ("A", "[VLOŽIŤ SCREENSHOT: PROFESIA.SK – STRÁNKA S PRACOVNÝMI PONUKAMI]"),
        ("B", "[VLOŽIŤ SCREENSHOT: VARECHA.SK – STRÁNKA S RECEPTAMI]"),
        ("C", "[VLOŽIŤ SCREENSHOT: EDUCAPLAY – STRÁNKA SO VZDELÁVACÍMI AKTIVITAMI]"),
    ]
    # tri možnosti VEDĽA SEBA (v jednom rade)
    n = 3
    gap = Cm(0.65)
    fw = (CONTENT_W - (n - 1) * gap) / n
    label_h = Cm(0.7)
    fh = Cm(4.8)
    circle_d = Cm(1.3)
    frame_y = y + label_h
    for i, (lab, txt) in enumerate(labels):
        fx = MARGIN + i * (fw + gap)
        # písmeno možnosti nad rámom
        add_text(s, fx, y, fw, label_h, lab, size=18, bold=True,
                 color=DARK_BLUE, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # rám na screenshot
        placeholder_frame(s, fx, frame_y, fw, fh, txt, size=9)
        # krúžok na zakrúžkovanie pod rámom
        add_answer_circle(s, fx + fw / 2, frame_y + fh + Cm(0.15) + circle_d / 2,
                          d=circle_d)

    # --- Úloha 2 ---
    y2 = frame_y + fh + Cm(0.15) + circle_d + Cm(0.5)
    y2 = add_task_label(s, y2, 2)
    add_zadanie(s, y2,
                "Pozrite si obrázok stránky s pracovnými ponukami. Zakrúžkujte "
                "pole, do ktorého zadáte miesto, kde chcete pracovať.",
                h=Cm(1.5))
    y2 += Cm(1.7)
    placeholder_frame(s, MARGIN, y2, CONTENT_W, Cm(4.6),
                      "[VLOŽIŤ SCREENSHOT: VYHĽADÁVACÍ FORMULÁR PROFESIA.SK "
                      "S VIDITEĽNÝM POĽOM „MIESTO PRÁCE“ A ĎALŠÍMI POLIAMI]",
                      size=11)
    add_footer(s)
    return s


# ======================================================================
# STRANA 3 – PRACOVNÝ LIST 2 – 1.2 Pracovné dokumenty
# ======================================================================
def page_ws2():
    s = add_slide()
    add_header(s, "Pracovný list 2", "1.2 Pracovné dokumenty")
    add_name_date(s, Cm(3.1))

    # --- Úloha 1 : editovateľná simulácia životopisu ---
    y = Cm(4.4)
    y = add_task_label(s, y, 1)
    add_zadanie(s, y,
                "Pozrite si životopis. Nájdite pole „Meno a priezvisko“ a "
                "napíšte doň: Ján Novák.",
                h=Cm(1.5))
    y += Cm(1.7)

    cv_h = Cm(9.2)
    cv = add_rect(s, MARGIN, y, CONTENT_W, cv_h, fill=WHITE, line=GREY, line_w=1.25)
    # hlavička CV
    add_rect(s, MARGIN, y, CONTENT_W, Cm(1.3), fill=LIGHT_BLUE)
    add_text(s, MARGIN + Cm(0.4), y, Cm(8), Cm(1.3), "Životopis",
             size=18, bold=True, color=DARK_BLUE, anchor=MSO_ANCHOR.MIDDLE)
    # foto placeholder + neutrálna ikona osoby
    photo_x = MARGIN + CONTENT_W - Cm(3.4)
    photo_y = y + Cm(1.7)
    add_rect(s, photo_x, photo_y, Cm(2.8), Cm(3.4), fill=PH_FILL,
             line=PH_LINE, line_w=1.0)
    # jednoduchá neutrálna ikona osoby (hlava + telo)
    add_shape(s, MSO_SHAPE.OVAL, photo_x + Cm(0.95), photo_y + Cm(0.55),
              Cm(0.9), Cm(0.9), fill=PH_LINE)
    add_shape(s, MSO_SHAPE.CHORD if False else MSO_SHAPE.ROUNDED_RECTANGLE,
              photo_x + Cm(0.55), photo_y + Cm(1.65), Cm(1.7), Cm(1.4),
              fill=PH_LINE)
    add_text(s, photo_x, photo_y + Cm(3.45), Cm(2.8), Cm(0.5), "Foto",
             size=9, color=GREY, align=PP_ALIGN.CENTER)

    # polia CV ako FORMULÁROVÉ VSTUPNÉ POLIA (ohraničené prázdne boxy)
    fld_x = MARGIN + Cm(0.5)
    fld_w = CONTENT_W - Cm(4.4)     # ľavý stĺpec (vedľa fotky)
    full_w = CONTENT_W - Cm(1.0)    # plná šírka (pod fotkou)

    def form_field(label, lx, ly, lw, box_h=Cm(0.9)):
        """Popis + prázdny ohraničený vstupný box (ako pole vo webovom formulári)."""
        add_text(s, lx, ly, lw, Cm(0.5), label, size=12, bold=True, color=GREY)
        box_y = ly + Cm(0.55)
        add_rect(s, lx, box_y, lw, box_h, fill=WHITE, line=PH_LINE,
                 line_w=1.25, round_=True)
        return box_y + box_h

    fy = y + Cm(1.7)
    # Meno a priezvisko – PRÁZDNE (účastník píše Ján Novák)
    fy = form_field("Meno a priezvisko", fld_x, fy, fld_w) + Cm(0.4)
    # Telefón
    fy = form_field("Telefón", fld_x, fy, fld_w) + Cm(0.4)
    # Pod fotkou – plná šírka
    fy = max(fy, photo_y + Cm(3.4) + Cm(0.3))
    fy = form_field("Pracovné skúsenosti", fld_x, fy, full_w, box_h=Cm(1.3)) + Cm(0.4)
    fy = form_field("Vzdelanie", fld_x, fy, full_w) + Cm(0.2)

    # --- Úloha 2 ---
    y2 = y + cv_h + Cm(0.5)
    y2 = add_task_label(s, y2, 2)
    add_zadanie(s, y2,
                "Pozrite si obrázok nového e-mailu. Zakrúžkujte tlačidlo, ktorým "
                "sa k správe pripája súbor.",
                h=Cm(1.5))
    y2 += Cm(1.7)
    placeholder_frame(s, MARGIN, y2, CONTENT_W, Cm(4.0),
                      "[VLOŽIŤ SCREENSHOT: ČISTÉ OKNO NOVEJ SPRÁVY V GMAILE "
                      "S VIDITEĽNOU SPODNOU LIŠTOU NÁSTROJOV A IKONOU "
                      "KANCELÁRSKEJ SPONKY]", size=11)
    add_footer(s)
    return s


# ======================================================================
# STRANA 4 – PRACOVNÝ LIST 3 – 1.3 Pracovné údaje
# ======================================================================
def draw_phone(slide, x, y, w, h):
    """Editovateľný SMARTFÓN (úzky, vysoký pomer ~1:2) + obrazovka.
    Vráti oblasť obrazovky (sx, sy, sw, sh)."""
    # telo telefónu – zaoblené rohy
    add_rect(slide, x, y, w, h, fill=DARK_BLUE, line=None, round_=True)
    side = Cm(0.28)
    top = Cm(0.95)
    bot = Cm(0.9)
    sx, sy = x + side, y + top
    sw, sh = w - 2 * side, h - top - bot
    add_rect(slide, sx, sy, sw, sh, fill=WHITE)
    # reproduktor (úzka štrbina hore)
    add_rect(slide, x + w / 2 - Cm(0.55), y + Cm(0.42), Cm(1.1), Cm(0.1),
             fill=LIGHT_BLUE, round_=True)
    # predná kamera
    add_shape(slide, MSO_SHAPE.OVAL, x + w / 2 + Cm(0.65), y + Cm(0.41),
              Cm(0.13), Cm(0.13), fill=LIGHT_BLUE)
    # domovský indikátor (pill) dole
    add_rect(slide, x + w / 2 - Cm(0.8), y + h - Cm(0.55), Cm(1.6), Cm(0.12),
             fill=LIGHT_BLUE, round_=True)
    return sx, sy, sw, sh


def draw_laptop(slide, x, y, w, h):
    """Editovateľný NOTEBOOK: obrazovka hore + širší lichobežníkový podstavec
    (klávesnica) so záveskom. Vráti oblasť obrazovky (sx, sy, sw, sh).
    w = šírka obrazovky; podstavec je širší a presahuje po oboch stranách."""
    base_block = Cm(1.05)              # výška záves + podstavec
    screen_h = h - base_block
    # rám obrazovky (bezel)
    add_rect(slide, x, y, w, screen_h, fill=DARK_BLUE, line=None, round_=True)
    pad = Cm(0.28)
    sx, sy = x + pad, y + pad
    sw, sh = w - 2 * pad, screen_h - 2 * pad
    add_rect(slide, sx, sy, sw, sh, fill=WHITE)
    # záves (tenký pruh pod obrazovkou)
    hinge_y = y + screen_h
    add_rect(slide, x - Cm(0.2), hinge_y, w + Cm(0.4), Cm(0.16), fill=GREY)
    # klávesnicový podstavec – lichobežník širší ako obrazovka (perspektíva)
    base_y = hinge_y + Cm(0.16)
    overhang = Cm(1.7)
    base = add_shape(slide, MSO_SHAPE.TRAPEZOID,
                     x - overhang, base_y, w + 2 * overhang, Cm(0.75),
                     fill=GREY)
    # trackpad náznak
    add_rect(slide, x + w / 2 - Cm(1.0), base_y + Cm(0.12), Cm(2.0), Cm(0.14),
             fill=RGBColor(0x7A, 0x7A, 0x7A), round_=True)
    return sx, sy, sw, sh


def page_ws3():
    s = add_slide()
    add_header(s, "Pracovný list 3", "1.3 Pracovné údaje")
    add_name_date(s, Cm(3.1))

    # --- Úloha 1 : výplatná páska na mobile ---
    y = Cm(4.4)
    y = add_task_label(s, y, 1)
    add_zadanie(s, y,
                "Pozrite si výplatnú pásku na obrazovke mobilu. Zakrúžkujte sumu, "
                "ktorá vám príde na bankový účet.",
                h=Cm(1.5))
    y += Cm(1.7)

    ph_w, ph_h = Cm(5.9), Cm(10.4)      # úzky, vysoký = smartfón
    ph_x = MARGIN + (CONTENT_W - ph_w) / 2
    sx, sy, sw, sh = draw_phone(s, ph_x, y, ph_w, ph_h)
    add_text(s, sx, sy + Cm(0.25), sw, Cm(0.7), "Výplatná páska",
             size=13, bold=True, color=DARK_BLUE, align=PP_ALIGN.CENTER)
    add_line(s, sx + Cm(0.3), sy + Cm(1.1), sw - Cm(0.6), color=LIGHT_GREY_LINE)
    rows = [
        ("Hrubá mzda:", "1 100,00 €"),
        ("Odvody a daň:", "257,30 €"),
        ("Čistá mzda – na účet:", "842,70 €"),
    ]
    ry = sy + Cm(1.6)
    for lab, val in rows:
        add_text(s, sx + Cm(0.3), ry, sw - Cm(0.6), Cm(0.7), lab,
                 size=12, bold=False, color=BLACK, align=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, sx + Cm(0.3), ry + Cm(0.65), sw - Cm(0.6), Cm(0.8), val,
                 size=15, bold=False, color=BLACK, align=PP_ALIGN.CENTER,
                 anchor=MSO_ANCHOR.MIDDLE)
        ry += Cm(2.0)

    # --- Úloha 2 : pracovný rozpis na notebooku ---
    y2 = y + ph_h + Cm(0.5)
    y2 = add_task_label(s, y2, 2)
    add_zadanie(s, y2,
                "Pozrite si pracovný rozpis na obrazovke notebooku. O koľkej sa "
                "v pondelok začína pracovná zmena? Napíšte čas.",
                h=Cm(1.5))
    y2 += Cm(1.7)

    lw, lh = Cm(12.0), Cm(5.8)
    lx = MARGIN + (CONTENT_W - lw) / 2
    sx2, sy2, sw2, sh2 = draw_laptop(s, lx, y2, lw, lh)
    add_text(s, sx2, sy2 + Cm(0.15), sw2, Cm(0.6), "Pracovný rozpis",
             size=12, bold=True, color=DARK_BLUE, align=PP_ALIGN.CENTER)
    sched = [
        ("Pondelok:", "8.00 – 16.00"),
        ("Utorok:", "10.00 – 18.00"),
        ("Streda:", "8.00 – 16.00"),
        ("Štvrtok:", "12.00 – 20.00"),
        ("Piatok:", "7.00 – 15.00"),
    ]
    row_y = sy2 + Cm(0.95)
    rh = (sh2 - Cm(1.0)) / 5
    for i, (d, t) in enumerate(sched):
        add_text(s, sx2 + Cm(0.8), row_y, Cm(4.5), rh, d, size=12, bold=True,
                 color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, sx2 + Cm(5.3), row_y, sw2 - Cm(5.8), rh, t, size=12,
                 color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
        if i < 4:
            add_line(s, sx2 + Cm(0.6), row_y + rh, sw2 - Cm(1.2),
                     color=RGBColor(0xE5, 0xE5, 0xE5), weight=0.75)
        row_y += rh

    ay = y2 + lh + Cm(0.5)
    add_text(s, MARGIN, ay, CONTENT_W, Cm(0.9),
             "Pracovná zmena sa v pondelok začína o __________ hod.",
             size=14, bold=False, color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
    add_footer(s)
    return s


# ======================================================================
# STRANA 5 – PRACOVNÝ LIST 4 – 1.4 Povolania a pracovné úlohy
# ======================================================================
def simple_icon(slide, x, y, sz, kind):
    """Jednoduchá generická editovateľná ikona z tvarov."""
    if kind == "calc":
        add_rect(slide, x, y, sz, sz, fill=None, line=GREY, line_w=1.5, round_=True)
        add_rect(slide, x + sz*0.18, y + sz*0.15, sz*0.64, sz*0.22, fill=LIGHT_BLUE)
        for r in range(2):
            for c in range(3):
                add_shape(slide, MSO_SHAPE.OVAL,
                          x + sz*(0.2 + c*0.24), y + sz*(0.5 + r*0.22),
                          sz*0.12, sz*0.12, fill=GREY)
    elif kind == "map":
        add_rect(slide, x, y, sz, sz, fill=None, line=GREY, line_w=1.5, round_=True)
        add_shape(slide, MSO_SHAPE.TEAR, x + sz*0.32, y + sz*0.2,
                  sz*0.36, sz*0.42, fill=LIGHT_BLUE, line=GREY, line_w=1.0)
        add_shape(slide, MSO_SHAPE.OVAL, x + sz*0.44, y + sz*0.3,
                  sz*0.12, sz*0.12, fill=WHITE)
    elif kind == "weather":
        add_rect(slide, x, y, sz, sz, fill=None, line=GREY, line_w=1.5, round_=True)
        add_shape(slide, MSO_SHAPE.OVAL, x + sz*0.2, y + sz*0.28,
                  sz*0.32, sz*0.32, fill=LIGHT_BLUE)
        add_shape(slide, MSO_SHAPE.CLOUD, x + sz*0.35, y + sz*0.4,
                  sz*0.45, sz*0.32, fill=RGBColor(0xEE,0xEE,0xEE), line=GREY, line_w=1.0)
    elif kind == "calendar":
        add_rect(slide, x, y, sz, sz, fill=None, line=GREY, line_w=1.5, round_=True)
        add_rect(slide, x + sz*0.15, y + sz*0.2, sz*0.7, sz*0.2, fill=LIGHT_BLUE)
        for r in range(2):
            for c in range(3):
                add_rect(slide, x + sz*(0.2 + c*0.22), y + sz*(0.5 + r*0.2),
                         sz*0.12, sz*0.12, fill=RGBColor(0xDD,0xDD,0xDD))


def page_ws4():
    s = add_slide()
    add_header(s, "Pracovný list 4", "1.4 Povolania a pracovné úlohy")
    add_name_date(s, Cm(3.1))

    # --- Úloha 1 : aplikácie na mobile ---
    y = Cm(4.4)
    y = add_task_label(s, y, 1)
    add_zadanie(s, y,
                "Pozrite si aplikácie na obrazovke mobilu. Zakrúžkujte aplikáciu, "
                "cez ktorú môžete so zamestnávateľom telefonovať aj s obrazom.",
                h=Cm(1.6))
    y += Cm(1.8)

    ph_w, ph_h = Cm(5.9), Cm(10.0)      # úzky, vysoký = smartfón
    ph_x = MARGIN + (CONTENT_W - ph_w) / 2
    sx, sy, sw, sh = draw_phone(s, ph_x, y, ph_w, ph_h)
    apps = ["Zoom", "Kalkulačka", "Mapy", "Počasie", "Kalendár"]
    icon_sz = Cm(1.4)
    gap = Cm(0.35)
    # rozloženie: riadok 1 = 3 ikony, riadok 2 = 2 ikony
    positions = []
    per_row = 3
    total_w = per_row * icon_sz + (per_row - 1) * gap
    start_x = sx + (sw - total_w) / 2
    row1_y = sy + Cm(0.7)
    for c in range(3):
        positions.append((start_x + c * (icon_sz + gap), row1_y))
    row2_total = 2 * icon_sz + gap
    start_x2 = sx + (sw - row2_total) / 2
    row2_y = row1_y + icon_sz + Cm(1.25)
    for c in range(2):
        positions.append((start_x2 + c * (icon_sz + gap), row2_y))

    icon_kinds = [None, "calc", "map", "weather", "calendar"]
    for i, name in enumerate(apps):
        ix, iy = positions[i]
        if name == "Zoom":
            placeholder_frame(s, ix, iy, icon_sz, icon_sz,
                              "[IKONA: ZOOM]", size=7)
        else:
            simple_icon(s, ix, iy, icon_sz, icon_kinds[i])
        add_text(s, ix - Cm(0.35), iy + icon_sz + Cm(0.03),
                 icon_sz + Cm(0.7), Cm(0.5), name, size=9, bold=False,
                 color=BLACK, align=PP_ALIGN.CENTER)

    # --- Úloha 2 : zoznam pracovných úloh (to-do app) ---
    y2 = y + ph_h + Cm(0.5)
    y2 = add_task_label(s, y2, 2)
    add_zadanie(s, y2,
                "Pozrite si zoznam pracovných úloh. Zakrúžkujte úlohu označenú "
                "slovom „Dnes“.",
                h=Cm(1.5))
    y2 += Cm(1.7)

    tw, th = Cm(15.0), Cm(6.2)
    tx = MARGIN + (CONTENT_W - tw) / 2
    add_rect(s, tx, y2, tw, th, fill=WHITE, line=GREY, line_w=1.25, round_=True)
    add_rect(s, tx, y2, tw, Cm(1.0), fill=LIGHT_BLUE)
    add_text(s, tx + Cm(0.4), y2, tw - Cm(0.8), Cm(1.0), "Zoznam úloh",
             size=13, bold=True, color=DARK_BLUE, anchor=MSO_ANCHOR.MIDDLE)
    todos = [
        ("Zavolať zákazníkovi", "Zajtra"),
        ("Poslať objednávku", "Dnes"),
        ("Skontrolovať sklad", "Piatok"),
        ("Pripraviť pracovné pomôcky", "Pondelok"),
    ]
    ry = y2 + Cm(1.0)
    rh = (th - Cm(1.0)) / 4
    for i, (task, dl) in enumerate(todos):
        add_shape(s, MSO_SHAPE.ROUNDED_RECTANGLE, tx + Cm(0.5),
                  ry + rh/2 - Cm(0.3), Cm(0.6), Cm(0.6), fill=None,
                  line=GREY, line_w=1.25)
        add_text(s, tx + Cm(1.4), ry, Cm(9.0), rh, task, size=13,
                 color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, tx + tw - Cm(4.0), ry, Cm(3.6), rh, dl, size=13,
                 color=GREY, align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)
        if i < 3:
            add_line(s, tx + Cm(0.4), ry + rh, tw - Cm(0.8),
                     color=RGBColor(0xE5,0xE5,0xE5), weight=0.75)
        ry += rh
    add_footer(s)
    return s


# ======================================================================
# STRANA 6 – PRACOVNÝ LIST 5 – 1.5 Bezpečnosť a ochrana údajov
# ======================================================================
def page_ws5():
    s = add_slide()
    add_header(s, "Pracovný list 5", "1.5 Bezpečnosť a ochrana údajov")
    add_name_date(s, Cm(3.1))

    # --- Úloha 1 : čo do životopisu nepatrí ---
    y = Cm(4.4)
    y = add_task_label(s, y, 1)
    add_zadanie(s, y,
                "Zakrúžkujte dva údaje, ktoré do životopisu nepatria.",
                h=Cm(1.2))
    y += Cm(1.5)

    items = [
        "Meno a priezvisko",
        "Kontaktné telefónne číslo",
        "Pracovné skúsenosti",
        "PIN ku platobnej karte",
        "Heslo do e-mailu",
    ]
    lst_h = Cm(7.0)
    add_rect(s, MARGIN, y, CONTENT_W, lst_h, fill=WHITE, line=GREY, line_w=1.25)
    add_rect(s, MARGIN, y, CONTENT_W, Cm(1.1), fill=LIGHT_BLUE)
    add_text(s, MARGIN + Cm(0.4), y, CONTENT_W - Cm(0.8), Cm(1.1),
             "Údaje v životopise", size=14, bold=True, color=DARK_BLUE,
             anchor=MSO_ANCHOR.MIDDLE)
    iy = y + Cm(1.5)
    rh = (lst_h - Cm(1.5)) / 5
    for it in items:
        add_answer_circle(s, MARGIN + Cm(1.3), iy + rh/2, d=Cm(1.0))
        add_text(s, MARGIN + Cm(2.4), iy, CONTENT_W - Cm(3.0), rh, it,
                 size=15, color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
        iy += rh

    # --- Úloha 2 : nastavenia telefónu ---
    y2 = y + lst_h + Cm(0.6)
    y2 = add_task_label(s, y2, 2)
    add_zadanie(s, y2,
                "Pozrite si možnosti v nastaveniach telefónu. Zakrúžkujte "
                "možnosť, pomocou ktorej môžete telefón chrániť PIN-om, heslom "
                "alebo odtlačkom prsta.",
                h=Cm(1.6))
    y2 += Cm(1.8)

    ph_w, ph_h = Cm(5.9), Cm(10.6)      # úzky, vysoký = smartfón
    ph_x = MARGIN + (CONTENT_W - ph_w) / 2
    sx, sy, sw, sh = draw_phone(s, ph_x, y2, ph_w, ph_h)
    add_text(s, sx, sy + Cm(0.25), sw, Cm(0.8), "Nastavenia",
             size=14, bold=True, color=DARK_BLUE, align=PP_ALIGN.CENTER)
    add_line(s, sx + Cm(0.3), sy + Cm(1.15), sw - Cm(0.6), color=LIGHT_GREY_LINE)
    settings = ["Zvuk", "Tapeta", "Zámok obrazovky", "Jas obrazovky"]
    ry = sy + Cm(1.45)
    rh = (sh - Cm(1.6)) / 4
    for i, opt in enumerate(settings):
        # jednoduchá neutrálna ikona
        add_rect(s, sx + Cm(0.35), ry + rh/2 - Cm(0.35), Cm(0.7), Cm(0.7),
                 fill=LIGHT_BLUE, line=None, round_=True)
        add_text(s, sx + Cm(1.35), ry, sw - Cm(1.7), rh, opt, size=12,
                 color=BLACK, anchor=MSO_ANCHOR.MIDDLE)
        if i < 3:
            add_line(s, sx + Cm(0.3), ry + rh, sw - Cm(0.6),
                     color=RGBColor(0xE5,0xE5,0xE5), weight=0.75)
        ry += rh
    add_footer(s)
    return s


# ======================================================================
# STRANA 7 – SPRÁVNE RIEŠENIA PRE LEKTORA
# ======================================================================
def page_solutions():
    s = add_slide()
    add_header(s, "Správne riešenia pre lektora", "Kľúč k pracovným listom 1.1 – 1.5")
    add_name_date(s, Cm(3.1)) if False else None

    y = Cm(3.6)
    sols = [
        ("1.1 Hľadanie práce",
         ["Úloha 1: A – Profesia.sk",
          "Úloha 2: pole „Miesto práce“"]),
        ("1.2 Pracovné dokumenty",
         ["Úloha 1: Ján Novák v poli „Meno a priezvisko“",
          "Úloha 2: ikona kancelárskej sponky"]),
        ("1.3 Pracovné údaje",
         ["Úloha 1: 842,70 €",
          "Úloha 2: 8.00 hod."]),
        ("1.4 Povolania a pracovné úlohy",
         ["Úloha 1: Zoom",
          "Úloha 2: Poslať objednávku"]),
        ("1.5 Bezpečnosť a ochrana údajov",
         ["Úloha 1: PIN ku platobnej karte a heslo do e-mailu",
          "Úloha 2: Zámok obrazovky"]),
    ]
    for title, lines in sols:
        box = add_rect(s, MARGIN, y, CONTENT_W, Cm(3.4), fill=WHITE,
                       line=LIGHT_GREY_LINE, line_w=1.0)
        add_rect(s, MARGIN, y, Cm(0.18), Cm(3.4), fill=DARK_BLUE)
        add_text(s, MARGIN + Cm(0.5), y + Cm(0.25), CONTENT_W - Cm(1.0), Cm(0.9),
                 title, size=15, bold=True, color=DARK_BLUE,
                 anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, MARGIN + Cm(0.7), y + Cm(1.15), CONTENT_W - Cm(1.4), Cm(2.0),
                 lines, size=13, color=BLACK, line_spacing=1.15)
        y += Cm(3.7)
    add_footer(s)
    return s


# ---------- ZOSTAVENIE ----------
page_title()
page_ws1()
page_ws2()
page_ws3()
page_ws4()
page_ws5()
page_solutions()

OUT = "/home/ubuntu/digitalna_gramotnost_praca/Digitalna_gramotnost_PRACA.pptx"
prs.save(OUT)
print("Saved:", OUT, "slides:", len(prs.slides._sldIdLst))
